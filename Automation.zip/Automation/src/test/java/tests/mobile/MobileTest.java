package tests.mobile;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * steps:
     * start android studio
     * start appium server at 4723
     * start appium inspector by set Capability
     * wright code
     * execute code
 */
public class MobileTest {
    public AndroidDriver driver;
    
    /**
    calculator Capability:
        {
            "platformName": "Android",
            " appium:automationName": "uiautomator2",
            "appium:app": "C:\\Users\\pradh\\Desktop\\Automation\\apps\\Calculator.apk"
        }
     */
    @BeforeTest
    public void setup() throws MalformedURLException, InterruptedException {
        String appiumServerUrl = "http://127.0.0.1:4723/";

        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("appium:automationName", "uiautomator2");
        capabilities.setCapability("appium:app", System.getProperty("user.dir") + "/apps/Calculator.apk");

        driver = new AndroidDriver(new URL(appiumServerUrl), capabilities);
        Thread.sleep(5000);

        System.out.println("Driver loaded successfully and app is opened !");
    }

    @Test
    public void test() {
        System.out.println("Test script is started performing !");

        driver.findElement(AppiumBy.accessibilityId("clear")).click();
        driver.findElement(AppiumBy.accessibilityId("7")).click();
        driver.findElement(AppiumBy.accessibilityId("plus")).click();
        driver.findElement(AppiumBy.accessibilityId("5")).click();
        driver.findElement(AppiumBy.accessibilityId("equals")).click();

        String result = driver.findElement(AppiumBy.className("android.widget.TextView")).getText();
        Assert.assertEquals(result, "12");

        System.out.println("All operations and validation completed !");
    }

    @AfterTest
    public void tearDown() throws InterruptedException {
        Thread.sleep(5000);
        driver.quit();

        System.out.println("Driver is quited successfully !");
    }
}
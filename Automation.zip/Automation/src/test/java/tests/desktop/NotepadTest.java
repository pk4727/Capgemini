package tests.desktop;

import org.openqa.selenium.Keys;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.WebElement;

import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.windows.WindowsDriver;

import java.net.URL;

public class NotepadTest {

    private WindowsDriver driver;

    /**
     * Setup method - Initializes Windows driver and launches the application
     */
    @BeforeClass
    public void setUp() throws Exception {
        System.out.println("🚀 Starting Desktop Automation Test");
        System.out.println("📂 Launching application via WinAppDriver...");
        // Use MutableCapabilities for WinAppDriver compatibility
        MutableCapabilities capabilities = new MutableCapabilities();
        capabilities.setCapability("platformName", "Windows");
        capabilities.setCapability("appium:app", "C:\\Windows\\System32\\notepad.exe");
//        capabilities.setCapability("appium:app","Microsoft.WindowsNotepad_8wekyb3d8bbwe!App"); not working
        capabilities.setCapability("appium:automationName", "NovaWindows");
        capabilities.setCapability("appium:ms:waitForAppLaunch", 10);
        capabilities.setCapability("appium:ms:experimental-webdriver", true);

        // Initialize Windows driver
        driver = new WindowsDriver(new URL("http://127.0.0.1:4723"), capabilities);
//        driver.manage().window().maximize(); not working
        Thread.sleep(5000);
        System.out.println("launched and connected successfully");
    }

    @Test(priority = 1)
    public void enterTextIntoEditor() {
        // Locate the "File" menu item in Notepad's menu bar
        WebElement fileMenu = driver.findElement(AppiumBy.name("File"));

        System.out.println("file element located");

        // Basic presence + displayed check
        Assert.assertNotNull(fileMenu, "'File' menu should be present");
        Assert.assertTrue(fileMenu.isDisplayed(), "'File' menu should be visible");
        System.out.println("file menu displayed");

        // find editor and check if its enabled
        WebElement textEditor = driver.findElement(AppiumBy.name("Text editor"));
        Assert.assertTrue(textEditor.isEnabled(), "editor not enabled");
        // eneter text in to editor
        textEditor.sendKeys("Here is the text entered from automation script");
        Assert.assertTrue(textEditor.isEnabled(), "editor is still enabled after editing");
    }

    @Test(priority = 3)
    public void saveFile() throws InterruptedException {
        WebElement editor = driver.findElement(AppiumBy.name("Text editor"));
        editor.sendKeys(Keys.chord(Keys.CONTROL, "s"));
        System.out.println("Pressed Ctrl+S to open Save dialog.");

        // %USERPROFILE%\Downloads\savedByAppiumOn_<timestamp>.txt
        String userProfile = System.getenv("USERPROFILE"); // e.g., C:\Users\YourName
        String fileName = "savedByAppiumOn_" + nowStamp() + ".txt";
        String fullPath = userProfile + "\\Downloads\\" + fileName;

        Thread.sleep(1000); // small pause; adjust if your machine is slower

        // Send the full path and press Enter to save.
        driver.switchTo().activeElement().sendKeys(fullPath + Keys.ENTER);
        System.out.println("Entered path and confirmed: " + fullPath);
    }

    // Utility to build a timestamp like 2026-02-13_10-42-05
    private String nowStamp() {
        java.time.format.DateTimeFormatter fmt = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
        return java.time.LocalDateTime.now().format(fmt);
    }

    @AfterSuite(alwaysRun = true)
    public void tearDown() {
        try {
            if (driver != null) {
                driver.quit();
                System.out.println("driver quit");
            } else {
                System.out.println("driver was null");
            }

        } catch (Exception e) {
            System.out.println("error caught while quitting" + e.getMessage());
        }
    }
}
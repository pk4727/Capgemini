package tests.desktop;

import io.appium.java_client.windows.WindowsDriver;
import io.appium.java_client.AppiumBy;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.*;

import java.net.URL;

public class NovaWindows_CalculatorTest {

    private WindowsDriver driver;

    @BeforeClass
    public void setUp() throws Exception {
        System.out.println("🚀 Starting Desktop Automation Test");
        System.out.println("📂 Launching application via WinAppDriver...");

        String appiumServerUrl = "http://127.0.0.1:4723/";

        // Use MutableCapabilities for WinAppDriver compatibility
        MutableCapabilities capabilities = new MutableCapabilities();
        capabilities.setCapability("platformName", "Windows");
        capabilities.setCapability("appium:app", "C:\\Windows\\System32\\calc.exe");
        capabilities.setCapability("appium:automationName", "NovaWindows");
        capabilities.setCapability("appium:ms:waitForAppLaunch", 10);
        capabilities.setCapability("appium:ms:experimental-webdriver", true);

        driver = new WindowsDriver(new URL(appiumServerUrl), capabilities);
        Thread.sleep(5000);

        System.out.println("Driver loaded successfully and app is opened !");
    }

    private WebElement findElementByAccessibilityId(String id) {
        return driver.findElement(AppiumBy.accessibilityId(id));
    }

    @Test
    @Ignore
    public void Addition() {
        System.out.println("Test script is started performing !");

        findElementByAccessibilityId("ClearEntryButton").click();
        findElementByAccessibilityId("num9Button").click();
        findElementByAccessibilityId("plusButton").click();
        findElementByAccessibilityId("num3Button").click();
        findElementByAccessibilityId("equalButton").click();

        String results = findElementByAccessibilityId("CalculatorResults").getText().replaceAll("[^0-9]", "");
        Assert.assertEquals(results, "12");

        System.out.println("All operations and validation completed !");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) driver.quit();
        System.out.println("Driver is quited successfully !");
    }
}

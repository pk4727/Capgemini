package tests.api;

import io.restassured.RestAssured;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.equalTo;

public class ApiTest {

    @Test
    public void getUserTest() {

        RestAssured.given()
                .baseUri("https://practice.expandtesting.com")
                .when()
                .get("/notes/api/health-check")
                .then()
                .log().all()
                .assertThat().statusCode(200)
                .body("message", equalTo("Notes API is Running"))
                .extract().response();

        System.out.println("API testing is successful without any error !");
    }
}
